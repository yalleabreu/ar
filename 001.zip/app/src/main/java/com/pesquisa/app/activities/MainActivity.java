package com.pesquisa.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.pesquisa.app.PesquisaApp;
import com.pesquisa.app.R;
import com.pesquisa.app.api.ApiClient;
import com.pesquisa.app.database.AppDatabase;
import com.pesquisa.app.database.entities.PendingResponse;
import com.pesquisa.app.models.Survey;
import com.pesquisa.app.services.LocationService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    private TextView tvStatus;
    private TextView tvSurveyTitle;
    private TextView tvPendingCount;
    private Button btnStartSurvey;
    private Button btnSendResponses;
    private Button btnViewPending;
    
    private Survey currentSurvey;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        requestPermissions();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        checkConfiguration();
        updatePendingCount();
    }
    
    private void initViews() {
        tvStatus = findViewById(R.id.tvStatus);
        tvSurveyTitle = findViewById(R.id.tvSurveyTitle);
        tvPendingCount = findViewById(R.id.tvPendingCount);
        btnStartSurvey = findViewById(R.id.btnStartSurvey);
        btnSendResponses = findViewById(R.id.btnSendResponses);
        btnViewPending = findViewById(R.id.btnViewPending);
        
        btnStartSurvey.setOnClickListener(v -> startSurvey());
        btnSendResponses.setOnClickListener(v -> sendResponses());
        btnViewPending.setOnClickListener(v -> viewPending());
    }
    
    private void requestPermissions() {
        String[] permissions = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO
        };
        
        boolean needRequest = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                needRequest = true;
                break;
            }
        }
        
        if (needRequest) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }
    
    private void checkConfiguration() {
        PesquisaApp app = PesquisaApp.getInstance();
        
        if (!app.isConfigured()) {
            tvStatus.setText("Configure a URL da API e o código da pesquisa");
            tvSurveyTitle.setVisibility(View.GONE);
            btnStartSurvey.setEnabled(false);
            return;
        }
        
        tvStatus.setText("Carregando pesquisa...");
        loadSurvey();
    }
    
    private void loadSurvey() {
        PesquisaApp app = PesquisaApp.getInstance();
        
        ApiClient.getService(app.getApiUrl()).getSurvey(app.getSurveyCode())
            .enqueue(new Callback<Survey>() {
                @Override
                public void onResponse(Call<Survey> call, Response<Survey> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        currentSurvey = response.body();
                        tvStatus.setText("Pesquisa carregada");
                        tvSurveyTitle.setText(currentSurvey.getTitle());
                        tvSurveyTitle.setVisibility(View.VISIBLE);
                        btnStartSurvey.setEnabled(true);
                        
                        Intent serviceIntent = new Intent(MainActivity.this, LocationService.class);
                        startService(serviceIntent);
                    } else {
                        tvStatus.setText("Erro ao carregar pesquisa");
                        btnStartSurvey.setEnabled(false);
                    }
                }
                
                @Override
                public void onFailure(Call<Survey> call, Throwable t) {
                    tvStatus.setText("Modo offline - Use dados salvos");
                    btnStartSurvey.setEnabled(true);
                }
            });
    }
    
    private void updatePendingCount() {
        new Thread(() -> {
            int count = PesquisaApp.getInstance().getDatabase().responseDao().getPendingCount();
            runOnUiThread(() -> {
                tvPendingCount.setText(count + " resposta(s) pendente(s)");
                btnSendResponses.setEnabled(count > 0);
                btnViewPending.setEnabled(count > 0);
            });
        }).start();
    }
    
    private void startSurvey() {
        Intent intent = new Intent(this, SurveyActivity.class);
        if (currentSurvey != null) {
            intent.putExtra("survey_json", currentSurvey.toJson());
        }
        startActivity(intent);
    }
    
    private void sendResponses() {
        btnSendResponses.setEnabled(false);
        btnSendResponses.setText("Enviando...");
        
        new Thread(() -> {
            AppDatabase db = PesquisaApp.getInstance().getDatabase();
            List<PendingResponse> pending = db.responseDao().getPendingResponses();
            
            if (pending.isEmpty()) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Nenhuma resposta pendente", Toast.LENGTH_SHORT).show();
                    btnSendResponses.setText("Enviar Respostas");
                    btnSendResponses.setEnabled(true);
                });
                return;
            }
            
            PesquisaApp app = PesquisaApp.getInstance();
            int sentCount = 0;
            
            for (PendingResponse response : pending) {
                try {
                    Response<Void> apiResponse = ApiClient.getService(app.getApiUrl())
                        .submitResponse(response.toApiRequest())
                        .execute();
                    
                    if (apiResponse.isSuccessful()) {
                        db.responseDao().markAsSent(response.getId());
                        sentCount++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
            int finalCount = sentCount;
            runOnUiThread(() -> {
                Toast.makeText(this, finalCount + " resposta(s) enviada(s)", Toast.LENGTH_SHORT).show();
                btnSendResponses.setText("Enviar Respostas");
                updatePendingCount();
            });
        }).start();
    }
    
    private void viewPending() {
        startActivity(new Intent(this, PendingResponsesActivity.class));
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, ConfigActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            checkConfiguration();
        }
    }
}
