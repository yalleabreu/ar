package com.pesquisa.app.database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

@Entity(tableName = "pending_responses")
public class PendingResponse {
    
    @PrimaryKey(autoGenerate = true)
    private int id;
    
    private String surveyCode;
    private String answersJson;
    private double latitude;
    private double longitude;
    private String audioPath;
    private String gender;
    private int age;
    private long createdAt;
    private boolean sent;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getSurveyCode() {
        return surveyCode;
    }
    
    public void setSurveyCode(String surveyCode) {
        this.surveyCode = surveyCode;
    }
    
    public String getAnswersJson() {
        return answersJson;
    }
    
    public void setAnswersJson(String answersJson) {
        this.answersJson = answersJson;
    }
    
    public double getLatitude() {
        return latitude;
    }
    
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    
    public double getLongitude() {
        return longitude;
    }
    
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
    public String getAudioPath() {
        return audioPath;
    }
    
    public void setAudioPath(String audioPath) {
        this.audioPath = audioPath;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public long getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
    
    public boolean isSent() {
        return sent;
    }
    
    public void setSent(boolean sent) {
        this.sent = sent;
    }
    
    public Map<String, Object> toApiRequest() {
        Map<String, Object> request = new HashMap<>();
        request.put("survey_code", surveyCode);
        request.put("latitude", latitude);
        request.put("longitude", longitude);
        request.put("gender", gender);
        request.put("age", age);
        
        try {
            JSONArray answersArray = new JSONArray(answersJson);
            java.util.List<Map<String, Object>> answers = new java.util.ArrayList<>();
            for (int i = 0; i < answersArray.length(); i++) {
                JSONObject obj = answersArray.getJSONObject(i);
                Map<String, Object> answer = new HashMap<>();
                answer.put("question_id", obj.optInt("question_id"));
                if (obj.has("answer_text")) answer.put("answer_text", obj.getString("answer_text"));
                if (obj.has("answer_option")) answer.put("answer_option", obj.getInt("answer_option"));
                if (obj.has("answer_scale")) answer.put("answer_scale", obj.getInt("answer_scale"));
                answers.add(answer);
            }
            request.put("answers", answers);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return request;
    }
}
