package com.pesquisa.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.pesquisa.app.PesquisaApp;
import com.pesquisa.app.R;
import com.pesquisa.app.database.entities.PendingResponse;
import com.pesquisa.app.models.Question;
import com.pesquisa.app.models.Survey;
import com.pesquisa.app.services.AudioRecordService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SurveyActivity extends AppCompatActivity {
    
    private Survey survey;
    private LinearLayout questionsContainer;
    private LinearLayout demographicsContainer;
    private Spinner spinnerGender;
    private EditText etAge;
    private Button btnSubmit;
    
    private FusedLocationProviderClient fusedLocationClient;
    private Location currentLocation;
    private String audioFilePath;
    
    private List<View> questionViews = new ArrayList<>();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
        
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        
        initViews();
        loadSurvey();
        startAudioRecording();
        getCurrentLocation();
    }
    
    private void initViews() {
        questionsContainer = findViewById(R.id.questionsContainer);
        demographicsContainer = findViewById(R.id.demographicsContainer);
        spinnerGender = findViewById(R.id.spinnerGender);
        etAge = findViewById(R.id.etAge);
        btnSubmit = findViewById(R.id.btnSubmit);
        
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item,
            new String[]{"Selecione", "Masculino", "Feminino", "Outro"});
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter(genderAdapter);
        
        btnSubmit.setOnClickListener(v -> submitSurvey());
    }
    
    private void loadSurvey() {
        String surveyJson = getIntent().getStringExtra("survey_json");
        
        if (surveyJson != null) {
            survey = Survey.fromJson(surveyJson);
        } else {
            survey = PesquisaApp.getInstance().getDatabase().surveyDao().getCachedSurvey(
                PesquisaApp.getInstance().getSurveyCode()
            );
        }
        
        if (survey == null) {
            Toast.makeText(this, "Erro ao carregar pesquisa", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(survey.getTitle());
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        if (survey.isDemographicsEnabled()) {
            demographicsContainer.setVisibility(View.VISIBLE);
        }
        
        buildQuestionViews();
    }
    
    private void buildQuestionViews() {
        questionsContainer.removeAllViews();
        questionViews.clear();
        
        if (survey.getQuestions() == null) return;
        
        for (int i = 0; i < survey.getQuestions().size(); i++) {
            Question question = survey.getQuestions().get(i);
            View questionView = createQuestionView(question, i + 1);
            questionsContainer.addView(questionView);
            questionViews.add(questionView);
        }
    }
    
    private View createQuestionView(Question question, int number) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(0, 16, 0, 16);
        container.setTag(question);
        
        TextView tvQuestion = new TextView(this);
        String questionText = number + ". " + question.getQuestionText();
        if (question.isRequired()) questionText += " *";
        tvQuestion.setText(questionText);
        tvQuestion.setTextSize(16);
        tvQuestion.setPadding(0, 0, 0, 8);
        container.addView(tvQuestion);
        
        switch (question.getQuestionType()) {
            case "multiple_choice":
                RadioGroup radioGroup = new RadioGroup(this);
                radioGroup.setTag("answer_view");
                if (question.getOptions() != null) {
                    for (int i = 0; i < question.getOptions().size(); i++) {
                        RadioButton rb = new RadioButton(this);
                        rb.setText(question.getOptions().get(i).getText());
                        rb.setId(i);
                        radioGroup.addView(rb);
                    }
                }
                container.addView(radioGroup);
                break;
                
            case "open_text":
                EditText editText = new EditText(this);
                editText.setTag("answer_view");
                editText.setHint("Digite sua resposta");
                editText.setMinLines(2);
                container.addView(editText);
                break;
                
            case "scale":
                LinearLayout scaleLayout = new LinearLayout(this);
                scaleLayout.setOrientation(LinearLayout.VERTICAL);
                scaleLayout.setTag("answer_view");
                
                TextView tvScaleValue = new TextView(this);
                tvScaleValue.setTag("scale_value");
                int mid = (question.getScaleMin() + question.getScaleMax()) / 2;
                tvScaleValue.setText(String.valueOf(mid));
                tvScaleValue.setTextSize(18);
                
                SeekBar seekBar = new SeekBar(this);
                seekBar.setMax(question.getScaleMax() - question.getScaleMin());
                seekBar.setProgress(mid - question.getScaleMin());
                seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        tvScaleValue.setText(String.valueOf(progress + question.getScaleMin()));
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {}
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {}
                });
                
                TextView tvRange = new TextView(this);
                tvRange.setText(question.getScaleMin() + " - " + question.getScaleMax());
                
                scaleLayout.addView(tvScaleValue);
                scaleLayout.addView(seekBar);
                scaleLayout.addView(tvRange);
                container.addView(scaleLayout);
                break;
                
            case "yes_no":
                RadioGroup yesNoGroup = new RadioGroup(this);
                yesNoGroup.setTag("answer_view");
                RadioButton rbYes = new RadioButton(this);
                rbYes.setText("Sim");
                rbYes.setId(1);
                RadioButton rbNo = new RadioButton(this);
                rbNo.setText("Não");
                rbNo.setId(0);
                yesNoGroup.addView(rbYes);
                yesNoGroup.addView(rbNo);
                container.addView(yesNoGroup);
                break;
        }
        
        return container;
    }
    
    private void startAudioRecording() {
        Intent intent = new Intent(this, AudioRecordService.class);
        intent.setAction("START");
        startService(intent);
    }
    
    private void stopAudioRecording() {
        Intent intent = new Intent(this, AudioRecordService.class);
        intent.setAction("STOP");
        startService(intent);
        audioFilePath = AudioRecordService.getLastRecordingPath();
    }
    
    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        
        CancellationTokenSource cts = new CancellationTokenSource();
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
            .addOnSuccessListener(location -> {
                if (location != null) {
                    currentLocation = location;
                }
            });
    }
    
    private void submitSurvey() {
        stopAudioRecording();
        
        try {
            JSONArray answersArray = new JSONArray();
            
            for (View questionView : questionViews) {
                Question question = (Question) questionView.getTag();
                View answerView = questionView.findViewWithTag("answer_view");
                
                JSONObject answer = new JSONObject();
                answer.put("question_id", question.getId());
                
                switch (question.getQuestionType()) {
                    case "multiple_choice":
                    case "yes_no":
                        RadioGroup rg = (RadioGroup) answerView;
                        int selected = rg.getCheckedRadioButtonId();
                        if (selected >= 0) {
                            answer.put("answer_option", selected);
                        } else if (question.isRequired()) {
                            Toast.makeText(this, "Responda todas as perguntas obrigatórias", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        break;
                        
                    case "open_text":
                        EditText et = (EditText) answerView;
                        String text = et.getText().toString().trim();
                        if (!text.isEmpty()) {
                            answer.put("answer_text", text);
                        } else if (question.isRequired()) {
                            Toast.makeText(this, "Responda todas as perguntas obrigatórias", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        break;
                        
                    case "scale":
                        LinearLayout scaleLayout = (LinearLayout) answerView;
                        TextView tvValue = scaleLayout.findViewWithTag("scale_value");
                        answer.put("answer_scale", Integer.parseInt(tvValue.getText().toString()));
                        break;
                }
                
                answersArray.put(answer);
            }
            
            PendingResponse pendingResponse = new PendingResponse();
            pendingResponse.setSurveyCode(survey.getCode());
            pendingResponse.setAnswersJson(answersArray.toString());
            
            if (currentLocation != null) {
                pendingResponse.setLatitude(currentLocation.getLatitude());
                pendingResponse.setLongitude(currentLocation.getLongitude());
            }
            
            pendingResponse.setAudioPath(audioFilePath);
            pendingResponse.setCreatedAt(System.currentTimeMillis());
            
            if (survey.isDemographicsEnabled()) {
                int genderPos = spinnerGender.getSelectedItemPosition();
                if (genderPos > 0) {
                    String[] genders = {"", "masculino", "feminino", "outro"};
                    pendingResponse.setGender(genders[genderPos]);
                }
                String ageStr = etAge.getText().toString().trim();
                if (!ageStr.isEmpty()) {
                    pendingResponse.setAge(Integer.parseInt(ageStr));
                }
            }
            
            new Thread(() -> {
                PesquisaApp.getInstance().getDatabase().responseDao().insert(pendingResponse);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Resposta salva!", Toast.LENGTH_SHORT).show();
                    finish();
                });
            }).start();
            
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao salvar resposta", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAudioRecording();
    }
}
