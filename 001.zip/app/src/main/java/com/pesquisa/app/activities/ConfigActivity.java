package com.pesquisa.app.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.pesquisa.app.PesquisaApp;
import com.pesquisa.app.R;

public class ConfigActivity extends AppCompatActivity {
    
    private EditText etApiUrl;
    private EditText etSurveyCode;
    private Button btnSave;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Configurações");
        }
        
        initViews();
        loadCurrentConfig();
    }
    
    private void initViews() {
        etApiUrl = findViewById(R.id.etApiUrl);
        etSurveyCode = findViewById(R.id.etSurveyCode);
        btnSave = findViewById(R.id.btnSave);
        
        btnSave.setOnClickListener(v -> saveConfig());
    }
    
    private void loadCurrentConfig() {
        PesquisaApp app = PesquisaApp.getInstance();
        etApiUrl.setText(app.getApiUrl());
        etSurveyCode.setText(app.getSurveyCode());
    }
    
    private void saveConfig() {
        String apiUrl = etApiUrl.getText().toString().trim();
        String surveyCode = etSurveyCode.getText().toString().trim();
        
        if (apiUrl.isEmpty()) {
            etApiUrl.setError("URL da API é obrigatória");
            return;
        }
        
        if (surveyCode.isEmpty()) {
            etSurveyCode.setError("Código da pesquisa é obrigatório");
            return;
        }
        
        if (surveyCode.length() != 6) {
            etSurveyCode.setError("Código deve ter 6 dígitos");
            return;
        }
        
        if (!apiUrl.endsWith("/")) {
            apiUrl += "/";
        }
        
        PesquisaApp app = PesquisaApp.getInstance();
        app.setApiUrl(apiUrl);
        app.setSurveyCode(surveyCode);
        
        Toast.makeText(this, "Configurações salvas!", Toast.LENGTH_SHORT).show();
        finish();
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
