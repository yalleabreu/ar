package com.pesquisa.app.database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "track_points")
public class TrackPoint {
    
    @PrimaryKey(autoGenerate = true)
    private int id;
    
    private double latitude;
    private double longitude;
    private long recordedAt;
    private boolean sent;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public double getLatitude() {
        return latitude;
    }
    
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    
    public double getLongitude() {
        return longitude;
    }
    
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
    public long getRecordedAt() {
        return recordedAt;
    }
    
    public void setRecordedAt(long recordedAt) {
        this.recordedAt = recordedAt;
    }
    
    public boolean isSent() {
        return sent;
    }
    
    public void setSent(boolean sent) {
        this.sent = sent;
    }
}
