package com.pesquisa.app.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Question {
    
    private int id;
    
    @SerializedName("question_text")
    private String questionText;
    
    @SerializedName("question_type")
    private String questionType;
    
    private List<Option> options;
    
    @SerializedName("scale_min")
    private int scaleMin;
    
    @SerializedName("scale_max")
    private int scaleMax;
    
    private boolean required;
    
    @SerializedName("order_num")
    private int orderNum;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getQuestionText() {
        return questionText;
    }
    
    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }
    
    public String getQuestionType() {
        return questionType;
    }
    
    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }
    
    public List<Option> getOptions() {
        return options;
    }
    
    public void setOptions(List<Option> options) {
        this.options = options;
    }
    
    public int getScaleMin() {
        return scaleMin;
    }
    
    public void setScaleMin(int scaleMin) {
        this.scaleMin = scaleMin;
    }
    
    public int getScaleMax() {
        return scaleMax;
    }
    
    public void setScaleMax(int scaleMax) {
        this.scaleMax = scaleMax;
    }
    
    public boolean isRequired() {
        return required;
    }
    
    public void setRequired(boolean required) {
        this.required = required;
    }
    
    public int getOrderNum() {
        return orderNum;
    }
    
    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }
}
