package com.pesquisa.app;

import android.app.Application;
import android.content.SharedPreferences;

import com.pesquisa.app.database.AppDatabase;

public class PesquisaApp extends Application {
    
    private static PesquisaApp instance;
    private SharedPreferences prefs;
    private AppDatabase database;
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        prefs = getSharedPreferences("pesquisa_prefs", MODE_PRIVATE);
        database = AppDatabase.getInstance(this);
    }
    
    public static PesquisaApp getInstance() {
        return instance;
    }
    
    public SharedPreferences getPrefs() {
        return prefs;
    }
    
    public AppDatabase getDatabase() {
        return database;
    }
    
    public String getApiUrl() {
        return prefs.getString("api_url", "");
    }
    
    public void setApiUrl(String url) {
        prefs.edit().putString("api_url", url).apply();
    }
    
    public String getSurveyCode() {
        return prefs.getString("survey_code", "");
    }
    
    public void setSurveyCode(String code) {
        prefs.edit().putString("survey_code", code).apply();
    }
    
    public boolean isConfigured() {
        return !getApiUrl().isEmpty() && !getSurveyCode().isEmpty();
    }
}
