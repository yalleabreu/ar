package com.pesquisa.app.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.pesquisa.app.database.dao.ResponseDao;
import com.pesquisa.app.database.dao.SurveyDao;
import com.pesquisa.app.database.entities.CachedSurvey;
import com.pesquisa.app.database.entities.PendingResponse;
import com.pesquisa.app.database.entities.TrackPoint;

@Database(entities = {PendingResponse.class, CachedSurvey.class, TrackPoint.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    
    private static AppDatabase instance;
    
    public abstract ResponseDao responseDao();
    public abstract SurveyDao surveyDao();
    
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    AppDatabase.class, "pesquisa_database")
                .fallbackToDestructiveMigration()
                .build();
        }
        return instance;
    }
}
