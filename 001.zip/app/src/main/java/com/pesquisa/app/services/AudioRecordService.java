package com.pesquisa.app.services;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.pesquisa.app.R;

import java.io.File;
import java.io.IOException;

public class AudioRecordService extends Service {
    
    private static final String CHANNEL_ID = "audio_service";
    private static final int NOTIFICATION_ID = 2;
    
    private MediaRecorder recorder;
    private static String lastRecordingPath;
    private boolean isRecording = false;
    
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if ("START".equals(action)) {
                startRecording();
            } else if ("STOP".equals(action)) {
                stopRecording();
            }
        }
        return START_NOT_STICKY;
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Gravação de Áudio",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Gravação em segundo plano");
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    private Notification createNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pesquisa")
            .setContentText("Gravando")
            .setSmallIcon(R.drawable.ic_mic)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build();
    }
    
    private void startRecording() {
        if (isRecording) return;
        
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        
        try {
            startForeground(NOTIFICATION_ID, createNotification());
            
            File audioDir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "recordings");
            if (!audioDir.exists()) {
                audioDir.mkdirs();
            }
            
            lastRecordingPath = new File(audioDir, "recording_" + System.currentTimeMillis() + ".mp3").getAbsolutePath();
            
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(lastRecordingPath);
            
            recorder.prepare();
            recorder.start();
            isRecording = true;
            
        } catch (IOException e) {
            e.printStackTrace();
            lastRecordingPath = null;
        }
    }
    
    private void stopRecording() {
        if (!isRecording) return;
        
        try {
            recorder.stop();
            recorder.release();
            recorder = null;
            isRecording = false;
            stopForeground(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String getLastRecordingPath() {
        return lastRecordingPath;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopRecording();
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
