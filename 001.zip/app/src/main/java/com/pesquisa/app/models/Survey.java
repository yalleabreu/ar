package com.pesquisa.app.models;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Survey {
    
    private int id;
    private String title;
    private String description;
    private String code;
    
    @SerializedName("demographics_enabled")
    private boolean demographicsEnabled;
    
    private List<Question> questions;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public boolean isDemographicsEnabled() {
        return demographicsEnabled;
    }
    
    public void setDemographicsEnabled(boolean demographicsEnabled) {
        this.demographicsEnabled = demographicsEnabled;
    }
    
    public List<Question> getQuestions() {
        return questions;
    }
    
    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }
    
    public String toJson() {
        return new Gson().toJson(this);
    }
    
    public static Survey fromJson(String json) {
        return new Gson().fromJson(json, Survey.class);
    }
}
