package com.pesquisa.app.activities;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pesquisa.app.PesquisaApp;
import com.pesquisa.app.R;
import com.pesquisa.app.adapters.PendingResponseAdapter;
import com.pesquisa.app.database.entities.PendingResponse;

import java.util.List;

public class PendingResponsesActivity extends AppCompatActivity {
    
    private RecyclerView recyclerView;
    private TextView tvEmpty;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_responses);
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Respostas Pendentes");
        }
        
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        loadPendingResponses();
    }
    
    private void loadPendingResponses() {
        new Thread(() -> {
            List<PendingResponse> responses = PesquisaApp.getInstance()
                .getDatabase().responseDao().getPendingResponses();
            
            runOnUiThread(() -> {
                if (responses.isEmpty()) {
                    tvEmpty.setVisibility(android.view.View.VISIBLE);
                    recyclerView.setVisibility(android.view.View.GONE);
                } else {
                    tvEmpty.setVisibility(android.view.View.GONE);
                    recyclerView.setVisibility(android.view.View.VISIBLE);
                    recyclerView.setAdapter(new PendingResponseAdapter(responses));
                }
            });
        }).start();
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
