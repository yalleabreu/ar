package com.pesquisa.app.database.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.pesquisa.app.database.entities.PendingResponse;
import com.pesquisa.app.database.entities.TrackPoint;

import java.util.List;

@Dao
public interface ResponseDao {
    
    @Insert
    void insert(PendingResponse response);
    
    @Query("SELECT * FROM pending_responses WHERE sent = 0 ORDER BY createdAt")
    List<PendingResponse> getPendingResponses();
    
    @Query("SELECT COUNT(*) FROM pending_responses WHERE sent = 0")
    int getPendingCount();
    
    @Query("UPDATE pending_responses SET sent = 1 WHERE id = :id")
    void markAsSent(int id);
    
    @Query("DELETE FROM pending_responses WHERE sent = 1")
    void deleteSentResponses();
    
    @Insert
    void insertTrack(TrackPoint trackPoint);
    
    @Query("SELECT * FROM track_points WHERE sent = 0 ORDER BY recordedAt")
    List<TrackPoint> getPendingTracks();
    
    @Query("UPDATE track_points SET sent = 1 WHERE id = :id")
    void markTrackAsSent(int id);
}
