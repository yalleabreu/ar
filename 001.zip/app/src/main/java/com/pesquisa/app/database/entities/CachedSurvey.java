package com.pesquisa.app.database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "cached_surveys")
public class CachedSurvey {
    
    @PrimaryKey(autoGenerate = true)
    private int id;
    
    private String code;
    private String surveyJson;
    private long cachedAt;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public String getSurveyJson() {
        return surveyJson;
    }
    
    public void setSurveyJson(String surveyJson) {
        this.surveyJson = surveyJson;
    }
    
    public long getCachedAt() {
        return cachedAt;
    }
    
    public void setCachedAt(long cachedAt) {
        this.cachedAt = cachedAt;
    }
}
