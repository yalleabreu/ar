package com.pesquisa.app.database.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.pesquisa.app.database.entities.CachedSurvey;
import com.pesquisa.app.models.Survey;

@Dao
public interface SurveyDao {
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void cacheSurvey(CachedSurvey survey);
    
    @Query("SELECT * FROM cached_surveys WHERE code = :code LIMIT 1")
    CachedSurvey getCachedSurveyEntity(String code);
    
    default Survey getCachedSurvey(String code) {
        CachedSurvey cached = getCachedSurveyEntity(code);
        if (cached != null && cached.getSurveyJson() != null) {
            return Survey.fromJson(cached.getSurveyJson());
        }
        return null;
    }
    
    @Query("DELETE FROM cached_surveys WHERE code = :code")
    void deleteCachedSurvey(String code);
}
