package com.pesquisa.app.api;

import com.pesquisa.app.models.Survey;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {
    
    @GET("api/survey/{code}")
    Call<Survey> getSurvey(@Path("code") String code);
    
    @POST("api/response")
    Call<Map<String, Object>> submitResponse(@Body Map<String, Object> response);
    
    @POST("api/responses/batch")
    Call<Map<String, Object>> submitBatch(@Body Map<String, Object> batch);
    
    @POST("api/track")
    Call<Map<String, Object>> submitTrack(@Body Map<String, Object> track);
    
    @POST("api/login")
    Call<Map<String, Object>> login(@Body Map<String, Object> credentials);
}
