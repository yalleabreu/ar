package com.pesquisa.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pesquisa.app.R;
import com.pesquisa.app.database.entities.PendingResponse;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PendingResponseAdapter extends RecyclerView.Adapter<PendingResponseAdapter.ViewHolder> {
    
    private List<PendingResponse> responses;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
    
    public PendingResponseAdapter(List<PendingResponse> responses) {
        this.responses = responses;
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_pending_response, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PendingResponse response = responses.get(position);
        
        holder.tvSurveyCode.setText("Pesquisa: " + response.getSurveyCode());
        holder.tvDate.setText(dateFormat.format(new Date(response.getCreatedAt())));
        
        StringBuilder info = new StringBuilder();
        if (response.getLatitude() != 0) {
            info.append("GPS: ").append(String.format(Locale.US, "%.4f, %.4f", 
                response.getLatitude(), response.getLongitude()));
        }
        if (response.getAudioPath() != null && !response.getAudioPath().isEmpty()) {
            if (info.length() > 0) info.append(" | ");
            info.append("Audio");
        }
        holder.tvInfo.setText(info.toString());
        
        holder.tvStatus.setText(response.isSent() ? "Enviado" : "Pendente");
    }
    
    @Override
    public int getItemCount() {
        return responses.size();
    }
    
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSurveyCode, tvDate, tvInfo, tvStatus;
        
        ViewHolder(View view) {
            super(view);
            tvSurveyCode = view.findViewById(R.id.tvSurveyCode);
            tvDate = view.findViewById(R.id.tvDate);
            tvInfo = view.findViewById(R.id.tvInfo);
            tvStatus = view.findViewById(R.id.tvStatus);
        }
    }
}
